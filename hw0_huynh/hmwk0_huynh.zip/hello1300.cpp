#include <iostream>

using namespace std; 

int main(){
    std::cout << "Hello, world! Hello CSCI 1300" << std::endl;
}