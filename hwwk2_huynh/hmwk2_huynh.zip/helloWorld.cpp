#include <iostream>

using namespace std;

int main(){
// Print "Hello, World!"  
    std::cout <<"Hello, World!" << std::endl;
    return 0;
}