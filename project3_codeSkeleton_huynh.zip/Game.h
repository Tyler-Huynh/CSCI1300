// CSCI 1300 Fall 2020
// Author: Tyler Huynh and Maggie Zhu
// Recitation: 306 - Sourav Chakraborty
// Project 3

#ifndef gameh
#define gameh

#include "Store.h"
#include "Player.h"
#include "Milestones.h"
#include "CurrentSupplies.h"

#include <iostream>
#include <string>

using namespace std;

class Game{
    private: 
        int days;
        Player player[5];
        Milestones milestones[15];
        CurrentSupplies currentSupplies;
    public:
        Game();

        Game(int days_1);

        void gameStart();
        void menu(); //printsMenu
        void rest(); 
        void contnueOn();
        void store(); //When the player decides to use the store
        void hunt(); //When the player wants to hunt, has puzzles within it
        void misfortunes(); //Random misfortunes using random numbers
        void raiders(); //Includes puzzles
        void gameEnd(); //Function when the player
        void statusUpdate(); //Prints out the status update
        void sortMilestones(string file, Milestones milestones[], int numMilestones); 
        void sortPlayer(string leader, string player_1, string player_2, string player_3, string player_4, Player player, int numPlayer); //Puts players into an array
        void ranking(string resultFile, string sortedArr[]); //Sorting algorithm, ranks the amount of time each player took and how long they lasted on the trail
        bool puzzles(int puzzleChoice); //Holds the puzzles for the various occurences 
    
};
#endif