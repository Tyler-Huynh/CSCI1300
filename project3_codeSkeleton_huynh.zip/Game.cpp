// CSCI 1300 Fall 2020
// Author: Tyler Huynh and Maggie Zhu
// Recitation: 306 - Sourav Chakraborty
// Project 3

#include "Store.h"
#include "Player.h"
#include "Date.h"
#include "Milestones.h"
#include "CurrentSupplies.h"
#include "Game.h"

#include <iostream>
#include <string>
#include <iomanip>
#include <vector>
#include <fstream>

using namespace std;

int split(string str, char sep, string arr[], int size); //Declaring the split function

Game :: Game(){ //Default constructor
    days = 0;
}

Game :: Game(int days_1){ //Paramerterized constructor
    days = days_1;
}

void Game :: gameStart(){
    cout << "THIS PROGRAM SIMULATES A TRIP OVER THE OREGON TRAIL FROM INDEPENDENCE," << endl;
    cout << "MISSOURI TO OREGON CITY, OREGON IN 1947. YOUR FAMILY OF FIVE WILL COVER" << endl;
    cout << "THE 2040 MILE OREGON TRAIL IN 5-6 MONTHS --- IF YOU MAKE IT ALIVE." << endl;

    /*
    1. Have the player enter a leader name and the name of the other players
    2. Place the players into the player array
    3. Set the starting balance to $1600
    4. Set the starting inverntory in the wagon
    5. Allow the player to choose the start date 03/28/1847 or to choose between 03/01/1847 and 05/01/1847.
    6. Input should be in month and day
    7. Based upon th start date they choose, update the date object
    8. Set days=0
    9. Call the store function to allow them to visit the store before the go on their journey
    */
    
}

void Game :: menu(){ //Prints the menu 
    /*
    1. Prints out a status update
        a. date
        b. miles traveled
        c. distance until the next milestone
        d. food
        e. bullets (ammo)
        f. cash
    2. Options: Rest, continue, hunt, quit
    3. Have the player choose an option
    4. Depending on the option, call the function 
    */
} 

void Game :: rest(){ 
    /*
    1. Add 1-3 days
    2.Subtract 3lbs of food, per person, per day
    */
}

void Game :: contnueOn(){
    /*
    1. Update inverntory to subtract 3lbs of food per person
    2. Update days to make 2 weeks pass
    3. Update the distance by adding 70 - 140
    */
}

void Game :: store(){ //When the player enter the store
    //Printing out the prompt
    cout << "YOU HAD SAVED $1600 TO SPEND FOR THE TRIP, AND YOU HAVE A" <<endl;
    cout << "WAGON. YOU WILL NEED TO SPEND THE REST OF YOUR MONEY ON THE" << endl;
    cout << "FOLLOWING ITEMS:" << endl;
    cout << endl;
    cout << "OXEN: YOU CAN SPEND $100-$200 ON YOUR TEAM. THE MORE YOU" << endl;
    cout << "SPEND, THE FASTER YOU'LL GO BECAUSE YOU'LL HAVE BETTER ANIMALS." <<endl;
    cout << endl;
    cout << "FOOD: THE MORE YOU HAVE, THE LESS CHANCE THERE IS OF GETTING SICK." <<endl;
    cout << endl;
    cout << "AMMUNITION: YOU WILL NEED BULLETS FOR ATTACKS BY ANIMALS ANDBANDITS, AND FOR HUNTING FOOD." << endl;
    cout << endl;
    cout << "MISCELLANEOUS SUPPLIES. THIS INCLUDES MEDICINE AND OTHERTHINGS YOU WILL NEED FOR SICKNESS AND EMERGENCY REPAIRS." << endl;
    cout << endl;
    cout << "YOU CAN SPEND ALL YOUR MONEY BEFORE YOU START YOUR TRIP, OR YOU" << endl;
    cout << "CAN SAVE SOME OF YOUR CASH TO SPEND AT FORTS ALONG THE WAY WHEN" << endl;
    cout << "YOU RUN LOW. HOWEVER, ITEMS COST MORE AT THE FORTS. YOU CAN ALSO" << endl;
    cout << "GO HUNTING ALONG THE WAY TO GET MORE FOOD." << endl;

    /*
    1. Print out the menu
    2. Have the user input ehat they want
    3. Implement a switch statement to track each item
    4. In each option there are specifications
        a. Oxen: must spend between 100 to 200 dollars
        b. Food: recommend the purchase of atleast 200 lbs per person
        c. misc:
            i. Wagons
            ii. Med kits
        5. Update balance
        6. Update the inventory
        7. Print out a bill
    */
}

bool Game :: puzzles(int puzzleChoice){ //Holds all of the puzzles
    bool correct = false;

    switch(puzzleChoice){
        case 1:{ //Guess the number
        
            string guess;
            int numGuess;
            int answer = rand() % 10+1; //Random number between 1 and 10

            cout << "Guess a number between 1 and 10!" << endl;
            getline(cin,guess);
            numGuess = stoi(guess);

            if (numGuess == answer){
                cout << "Congrats you did it!" << endl;
                correct = true;
        
            }else{ 
            
                cout << "Sorry, better luck next time!" << endl;
                correct = false;
            }
         }

        //The other puzzles are yet to be determined
        case 2:{ //Riddle (age)
        
        }

        case 3:{ //Solve a math problem
        
        }

    }
    return correct;
}
void Game :: hunt(){ //Called when the player chooses to hunt and has puzzles as well
    /*
    1. Use the rand function to pick animal encounter
    2. Allow the user to choose yes or no to hunting
    3. If yes... if they have more than 10 bullets (successful)
    4. Give a puzzle for the player to solve
    5. Update the food inventory based upon the hunt
        a. rabbit - 5lbs
        b. fox - 10lbs
        c. deer - 60lbs
        d. bear - 200lbs
        e. moose - 500lbs
    6. Update the ammunition based upon the animal they hunted
        a. rabbit - 10
        b. fox - 8
        c. deer - 5
        d. bear - 10
        e. moose - 12
    7. Ask the player how well they would like to eat
        a. poorly - 2lbs per person
        b. moderately - 3lbs per person
        c. well - 5lbs per person
    8. Update the total food after eating, if over 1000lbs, leave excess behind
    6. If no then continue
    */

    //Use random function to pick an animal
    int encounter;
    encounter = rand()%102; //Random number between 0-101 

    //Probablity to encounter animals
    if (encounter >= 0 && encounter <= 49){ //Rabbit
        cout << "You have encountered a rabbit!" << endl;

    }else if(encounter >= 50 && encounter <= 74){ //Fox
        cout << "You have encountered a fox!" << endl;

    }else if(encounter >=75 && encounter <= 89){ //Deer
        cout << "You have encountered a deer!" << endl;

    }else if(encounter >=90 && encounter <=96){ //Bear
        cout << "You have encountered a bear!" << endl;

    }else if(encounter <=97 && encounter <= 101){ //Moose
        cout << "You have encountered a moose!" << endl;
    }

    //Prompting to hunt
    cout << "Would you like to hunt?" << endl;
    cout << "1. Yes" << endl;
    cout << "2. No " << endl;

    //User input
    string huntChoice;
    int huntChoiceInt;
    getline(cin, huntChoice);
    huntChoiceInt = stoi(huntChoice);

    //Hunting process
    switch(huntChoiceInt){
        case 1:{ //Yes

            //You might need an object for the inventory
            if (currentSupplies.getBullets() >=10){
                int puzzleChoice = rand() % 4; //Picks a random number 1-3
                bool correct = false;
                correct = puzzles(puzzleChoice);

                if (correct == true){
                    //Total up food
                    //Subtract ammo
                    //Ask how they want to eat
                    //If the total food exceeds 1000 lbs., cut the food at 1000lbs. and print a message explaining they had to leave the rest of the food behind.
                
                }else{
                    //subtract ammo
                }
                
            }
       
        }

        case 2:{ //No
            break;
        }
    }
}

void Game :: misfortunes(){
    /*
    1. Use the random function to determine whether not a misfortune has occurred (40%)
    2. Use random function to determine what misfortune has occurred (1-3)
        a. Sickness
            i. Choose at random which member gets sick
            ii. Print out the type of sickness (Dysentary)
            iii. If party has med kit then chances of dying is 50%
            iv. If party does not have med kit then the chances of dying are altered
                A. Rest : 3 days, 30% chance of dying
                B. Press On : 70% chance of dying
            v. If the leader dies, Game Over
            vi. Print out dying message
        b. Oxen dies
            i. Print out message
            ii. Update inventory
            iii. If all oxen are dead, they cannot continue
        c. Wagon Breaks
            i. Print out message
            ii. If they have spare parts, they can continue, update inventory
            iii. If they do not have spare parts, they cannot continue
    */
}

void Game :: raiders(){ //Includes puzzles
    /*
    1. Use the equation to determine probablity (values will be between 5-50)
    2. Use the random function to determine the outcome
    3. If there is a raider
        a. Print out a message
        b. Run: Lose 1 ox, 10lbs of food, 1 wagon part
        c. Attack:
            i. Call puzzle funtion
            ii. If passed, gains 50lbs of food and 50 bullets
            iii. If lost, they lose 1/4 of their cash and 50 bullets
        d. Surrender: lose 1/4 of cash
    */
}

void Game :: gameEnd(){ //function when the player dies
    /*
    1. This function is called in the following conditions
        a. They successfully reach the end
        b. Everyone dies or just the leader dies
        c. No food, oxen, wagon
    2. Write the final stats to a file called results.txt
        a. Leader name
        b. Miles traveled
        c. Food remaining
        d. Cash Remaining
    3. Write the leader name and days it took to leaderboard.txt
        a. Implement a selection sort to rank them
        b. To do this, call the ranking member function
    */
}

void Game :: statusUpdate(){
    //Prints out the following:
        //The date
        //The miles the group has traveled
        //The distance until next milestone
        //The food still available
        //The bullets available
        //The remaining balance
}

void Game :: sortMilestones(string file, Milestones milestones[], int numMilestones){ //Function to sort the milestones
    /*
    1. Open and the read file like usual
    2. Place the milestone name and the distance in the array of milestones objects
    */

    int index;

    //Reading the file
    ifstream in_file;
    in_file.open (file);

    string line;

    //File does not open
    if (in_file.fail()){
        cout << "File failed to open! " << endl;
    }

    //Reading the file
    while (getline (in_file,line)){
        string arr[15];

        //If it is not an empty line
        if(line.length()!=0){
            if (line[0]>='A' && line[0]<='Z'){ //If the line is a milestone name
                milestones[index].setMilestoneName(line);
            

            }else{ 
                split(line, 'm', arr , 1); //Splits it so it just the num
                milestones[index].setDistance(stoi(arr[0]));
            }
            index++;
        }
    }
}

void Game :: sortPlayer(string leader, string player_1, string player_2, string player_3, string player_4, Player player, int numPlayer){ //Puts players into an array
    /*
    1. Create a player object
    2. Place the name and the boolean into the player object
    3. Make an array (or vec) out of these objects
    */
}
void Game :: ranking(string resultFile, string sortedArr[]){ //sorting algorithm, ranks how long it took each player
    /*
    1. Read the leaderboard.txt 
    2. Insert the results of the leaderboard.txt file into a sorted array
    3. Using selection sort, sort out the results (least days to most days)
    4. Rewrite the sorted array to the file with days and names
    5. The least amount of days should be the top
    */
}

/*
* This function is taking a string and splitting it and is inserting it into an array and outputing the max number if pieces
* Parameters: str, sep, arr, size
* Return: pos
*/

int split(string str, char sep, string arr[], int size){ //split function
    int pos = 0; //Delcared variables
    string substr;
    string word = "";
   
    for (int i=0; i < str.length(); i++){ //Traversing the array to find the seperator
        if (str[i] != sep){
            word = word + str[i]; //Creating the word
        
        }else if (str[i] == sep){
            arr[pos] = word;
            pos++;
            word = ""; //Resetting the word
        }
    }
        if (word == ""){ //If the word is equal to nothing
            return 0;

        }else if (pos >= size){ //If the amount of words that are split is larger than the size
            return -1;

        }else if (word.length() == 0 || size == 0){
            return 0;
        
        }else{ 
            arr[pos] = word;
            pos++;
        }

    return pos;  
}